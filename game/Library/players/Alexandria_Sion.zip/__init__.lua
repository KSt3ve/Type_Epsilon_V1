Include'THlib\\player\\sion\\sion.lua'
AddPlayerToPlayerList('Alexandria Sion','sion_player','Sion')