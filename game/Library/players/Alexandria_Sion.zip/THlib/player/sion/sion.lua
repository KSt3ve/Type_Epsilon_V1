-- Based on LuaSTG Ex Plus's default Marisa player.
-- Differences between that and this file are by TruDev#4528.

sion_player = Class(player_class)

function sion_player:init(slot)
    LoadTexture('sion_player', 'THlib\\player\\sion\\sion.png')
    LoadTexture('sion_tornado', 'THlib\\player\\sion\\sion_tornado.png')
    LoadTexture('sion_lightning', 'THlib\\player\\sion\\sion_lightning.png')
    LoadTexture('SionLaser', 'THlib\\player\\sion\\SionLaser.png')
    LoadImageFromFile('sion_hit_par', 'THlib\\player\\sion\\sion_hit_par.png')
    LoadImageGroup('sion_player', 'sion_player', 0, 0, 32, 48, 8, 3, 1, 1)
    LoadImage('sion_bullet', 'sion_player', 0, 144, 32, 16, 16, 16)
    LoadAnimation('sion_bullet_ef', 'sion_player', 0, 144, 32, 16, 4, 1, 4)
    SetImageState('sion_bullet', '', Color(0x80FFFFFF))
    LoadImage('sion_page', 'sion_player', 192, 224, 32, 16, 8, 8)
    SetImageState('sion_page', '', Color(0xEEFFFFFF))
    LoadAnimation('sion_page_ef', 'sion_player', 64, 224, 32, 32, 4, 1, 2)
    SetAnimationState('sion_page_ef', 'mul+add', Color(0x80FFFFFF))
    LoadImage('sion_support', 'sion_player', 144, 144, 16, 16)
    LoadImage('sion_laser_light', 'sion_player', 224, 224, 32, 32)
    SetImageState('sion_laser_light', 'mul+add', Color(0xFFFFFFFF))
    LoadAnimation('sion_tornado', 'sion_tornado', 0, 0, 217, 300, 4, 4, 5, 217, 300)
    LoadImage('sion_lightning', 'sion_lightning', 0, 0, 80, 232, 64, 160)
    SetAnimationState('sion_tornado', '', Color(0xBFFFFFFF))
    SetImageState('sion_lightning', 'mul+add', Color(0xFFFFFFFF))
    SetAnimationCenter('sion_tornado', 108, 200)
    LoadPS('sion_hit', 'THlib\\player\\sion\\sion_hit.psi', 'sion_hit_par')
    player_class.init(self)
    self.name = 'Sion'
    self.imgs = {}
    self.A = 1
    self.B = 1
    for i = 1, 24 do self.imgs[i] = 'sion_player' .. i end
    self.hspeed = 5
    self.offset = {600, 600} --, 600, 600}
    self.slist = {
        {nil, nil, nil, nil}, {{0, 32, 0, 29}, nil, nil, nil},
        {{-30, 10, -8, 23}, {30, 10, 8, 23}, nil, nil},
        {{-30, 0, -10, 24}, {0, 32, 0, 32}, {30, 0, 10, 24}, nil},
        {
            {-30, 10, -15, 20}, {-12, 32, -7.5, 29}, {12, 32, 7.5, 29},
            {30, 10, 15, 20}
        }, {
            {-30, 10, -15, 20}, {-7.5, 32, -7.5, 29}, {7.5, 32, 7.5, 29},
            {30, 10, 15, 20}
        }
    }
    self.anglelist = {
        {90, 90, 90, 90}, {90, 90, 90, 90}, {95, 85, 90, 90}, {95, 90, 85, 90},
        {95, 90, 90, 85}
    }
    self.doubleLaserDeviation = 4 -- Deviation of laser from 90deg
    self.Page = function(idx)
        PlaySound('msl', 0.2)
        for _, i in ipairs(idx) do
            if self.sp[i] and self.sp[i][3] > 0.5 then
                New(sion_page, 'sion_page', self.supportx + self.sp[i][1],
                    self.supporty + self.sp[i][2], 16, 90, 2)
            end
        end
    end
end

function sion_player:frame()
    self.offset = {600, 600}
    player_class.frame(self)
end

function sion_player:shoot()
    if self.nextspell <= 0 then
        local power = int(lstg.var.power / 100)
        for i = 0, 3 do
            if self.timer % 8 == i * 2 then
                PlaySound('plst00', 0.15, self.x / 1024)
                New(sion_bullet, 'sion_bullet', self.x, self.y, 24, 90, 2.35)
            end
            if i + 1 >= power then
                break
            end
        end
        if self.slow == 1 then
            if self.support > 0 then
                if self.timer % 12 == 0 then
                    PlaySound('lazer02', 0.025)
                end
                local width = 16 + (power - 1) % 2 * 16
                for i = 1, 2 do
                    local target = nil
                    local angle = 90
                    if power > 2 then
                        angle = i * self.doubleLaserDeviation + 90 - 1.5 * self.doubleLaserDeviation
                    end
                    for j, o in ObjList(GROUP_ENEMY) do
                        if o.colli and IsInLaser(self.x, self.y, angle, o, width) then
                            local d = Dist(o.x, o.y, self.x, self.y)
                            if d < self.offset[i] then
                                target = o
                                self.offset[i] = d
                            end
                        end
                    end
                    for j, o in ObjList(GROUP_NONTJT) do
                        if o.colli and IsInLaser(self.x, self.y, angle, o, width) then
                            local d = Dist(o.x, o.y, self.x, self.y)
                            if d < self.offset[i] then
                                target = o
                                self.offset[i] = d
                            end
                        end
                    end
                    if target then
                        self.offset[i] = max(0, self.offset[i] - target.b)
                        New(sion_laser_hit, self.x + self.offset[i] * cos(angle),
                            self.y + self.offset[i] * sin(angle))
                        if target.class.base.take_damage then
                            target.class.base.take_damage(target, width * 0.01 + power * 0.08)
                        end
                        if target.hp > target.maxhp * 0.1 then
                            PlaySound('damage00', 0.3, target.x / 1024)
                        else
                            PlaySound('damage01', 0.6, target.x / 1024)
                        end
                    end
                    if power <= 2 then break end
                end
            end
        else
            if power <= 2 then
                if self.timer % 16 == 0 then
                    self.Page({1, 2, 3, 4})
                end
            elseif power == 3 then
                if self.timer % 16 == 0 then self.Page({1, 3}) end
                if self.timer % 16 == 8 then self.Page({2}) end
            else
                if self.timer % 16 == 0 then self.Page({1, 4}) end
                if self.timer % 16 == 8 then self.Page({2, 3}) end
            end
        end
    end
end

function sion_player:spell()
    self.collect_line = self.collect_line - 300
    New(tasker, function()
        task.Wait(90)
        self.collect_line = self.collect_line + 300
    end)
    New(player_spell_mask, 0, 180, 255, 30, 240, 30)
    PlaySound('slash', 1.0)
    PlaySound('nep00', 1.0)
    self.nextspell = 300
    self.protect = 360
    New(sion_tornado, -self.x, -280, 0, 45, 210, 45, self)
    self.spell_init = self.timer
    
    New(tasker, function()
        -- for i = 1, 27 do
        while self.timer - self.spell_init <= 270 do
            New(sion_lightning, self.x, self.y, ran:Int(0, 360), 12, 2, self)
            task.Wait(ran:Int(6, 10))
        end
    end)

    New(tasker, function()
        task.Wait(270)
        New(bullet_killer, self.x, self.y)
        PlaySound('slash', 1.0)
    end)
    misc.ShakeScreen(270, 3)
end

function sion_player:render()
    local sz = 1.2 + 0.1 * sin(self.timer * 0.2)
    -- support
    SetImageState('sion_support', '', Color(0xFFFFFFFF))
    for i = 1, 4 do
        if self.sp[i] then
            Render('sion_support', self.supportx + self.sp[i][1],
                   self.supporty + self.sp[i][2], 0, self.sp[i][3], 1)
        end
    end
    -- support deco
    SetImageState('sion_support', '', Color(0x80FFFFFF))
    for i = 1, 4 do
        if self.sp[i] then
            Render('sion_support', self.supportx + self.sp[i][1],
                   self.supporty + self.sp[i][2], 0, self.sp[i][3] * sz, sz)
        end
    end
    if self.support > 0 and self.fire == 1 and self.slow == 1 and self.nextshoot <= 0 then
        local num = 30 / (self.support + 1)
        local timer = self.timer * 16
        local power = int(lstg.var.power / 100)
        local width = 16 + (power - 1) % 2 * 16
        for i = 1, 2 do
            local angle = 90
            if power > 2 then
                angle = i * self.doubleLaserDeviation + 90 - 1.5 * self.doubleLaserDeviation
            end
            if self.offset[1] < 600 then
                CreateLaser(self.x, self.y, angle, width, timer, Color(0x804040FF), self.offset[1])
            else
                CreateLaser(self.x, self.y, angle, width, timer, Color(0x80FFFFFF), 600)
            end
            if power <= 2 then break end
        end
    end
    player_class.render(self)
end

sion_bullet = Class(player_bullet_straight)

function sion_bullet:kill()
    for _, v in ipairs({3, 4, 5}) do
        New(sion_bullet_ef, self.x, self.y, self.rot, v)
    end
end

sion_page = Class(player_bullet_straight)

function sion_page:frame() self.vy = min(self.timer / 3 + 3, 12) end
function sion_page:kill()
    PlaySound('msl2', 0.3)
    local a, r = ran:Float(0, 360), ran:Float(0, 6)
    New(sion_page_ef, self.x + r * cos(a), self.y + r * sin(a), self.dmg, 5)
end

sion_page_ef = Class(object)

function sion_page_ef:init(x, y, dmg, t)
    self.x = x
    self.y = y
    self.a = 6
    self.b = 6
    self.img = 'sion_page_ef'
    self.group = GROUP_PLAYER_BULLET
    self.dmg = dmg / 8
    self.killflag = true
    self.layer = LAYER_PLAYER_BULLET
    self.mute = true
    self.t = t
end

function sion_page_ef:frame()
    if self.timer == 3 and self.t > 0 then
        local a, r = ran:Float(0, 360), ran:Float(9, 18)
        New(sion_page_ef, self.x + r * cos(a), self.y + r * sin(a),
            self.dmg * 7.5, self.t - 1)
    end
    if self.timer == 15 then Del(self) end
end

sion_bullet_ef = Class(object)

function sion_bullet_ef:init(x, y, rot, v)
    self.x = x
    self.y = y
    self.rot = rot
    self.vx = v * cos(rot)
    self.vy = v * sin(rot)
    self.img = 'sion_bullet_ef'
    self.layer = LAYER_PLAYER_BULLET + 50
end

function sion_bullet_ef:frame() if self.timer == 7 then Del(self) end end
function sion_bullet_ef:render()
    SetAnimationState('sion_bullet_ef', '',
                      Color(128 - 8 * self.timer, 255, 255, 255))
    object.render(self)
end

sion_laser_hit = Class(object)

function sion_laser_hit:init(x, y)
    self.x = x
    self.y = y
    self.group = GROUP_GHOST
    self.layer = LAYER_PLAYER_BULLET + 60
    self.img = 'sion_hit'
end

function sion_laser_hit:frame()
    if self.timer == 4 then ParticleStop(self) end
    if self.timer == 10 then Del(self) end
end

sion_tornado = Class(object)

function sion_tornado:init(x, y, rot, turnOnTime, wait, turnOffTime, p)
    self.player = p
    self.rot = rot
    self.rotMul = -1
    self.x = x
    self.vx = 5
    if self.x > 0 then
        self.vx = -self.vx
        self.rotMul = 1
    end
    self.y = y
    self.vy = 4.5
    self.ay = -0.03
    self.img = 'sion_tornado'
    self.group = GROUP_GHOST
    self.layer = LAYER_PLAYER_BULLET
    self.hscale = 0
    self.vscale = 0
    self.a = 0
    self.b = 0
    self.killflag = true
    self.bound = false
    task.New(self, function()
        for i = 0, turnOnTime do
            self.hscale = 1.2 * i / turnOnTime
            self.vscale = 1.5 * i / turnOnTime
            task.Wait(1)
        end
        task.Wait(wait)
        for i = 0, turnOffTime do
            self.hscale = 1.2 * (1 - i / turnOffTime)
            self.vscale = 1.5 * (1 - i / turnOffTime)
            task.Wait(1)
        end
        Del(self)
    end)
    task.New(self, function()
        task.Wait(8)
        while self.timer <= 270 do
            New(sion_lightning, self.x + ran:Float(-10, 10) * self.vscale, self.y + ran:Float(-20, 100) * self.hscale, ran:Int(0, 360), 12, 1.5, self)
            task.Wait(ran:Int(6, 10))
        end
    end)
    task.New(self,function()
        for i=6,30 do
            self.rot = self.rotMul * 20 * sin(i * 3)
            task.Wait(1)
        end
    end)
    New(sion_tornado_dmg, self.x, self.y, turnOnTime, wait, turnOffTime, self)
end

function sion_tornado:frame()
    task.Do(self)
    if self.x > lstg.world.r or self.x < lstg.world.l then
        self.vx = -self.vx
        self.rotMul = -self.rotMul
        self.rot = 90
        task.New(self,function()
            for i=1,30 do
                self.rot = self.rotMul * 20 * sin(i * 3)
                task.Wait(1)
            end
        end)
    end
    New(bomb_bullet_killer, self.x, self.y + 64, 150, 150, false)
end


sion_tornado_dmg = Class(object)

function sion_tornado_dmg:init(x, y, turnOnTime, wait, turnOffTime, tornado)
    self.tornado = tornado
    self.x = x
    self.y = y
    self.a = 0
    self.b = 0
    self.group = GROUP_PLAYER_BULLET
    self.layer = LAYER_PLAYER_BULLET
    self.dmg = 0.2
    self.rect = true
    self.killflag = true
    self.bound = false
    task.New(self, function()
        for i = 0, turnOnTime do
            self.a = 128 * i / turnOnTime
            self.b = 180 * i / turnOnTime
            task.Wait(1)
        end
        task.Wait(wait)
        for i = 0, turnOffTime do
            self.a = 128 * (1 - i / turnOffTime)
            self.b = 180 * (1 - i / turnOffTime)
            task.Wait(1)
        end
        Del(self)
    end)
end

function sion_tornado_dmg:frame()
    task.Do(self)
    self.x = self.tornado.x
    self.y = self.tornado.y + self.b / 2
end

sion_lightning = Class(object)

function sion_lightning:init(x, y, rot, v, dmg, p)
    self.player = p
    self.x = x + 90 * cos(rot)
    self.y = y + 90 * sin(rot)
    self.rot = rot + 90
    self.img = 'sion_lightning'
    self.group = GROUP_PLAYER_BULLET
    self.layer = LAYER_PLAYER_BULLET
    self.dmg = dmg
    self.rect = true
    self.killflag = true
    PlaySound('enep02', 1.0, self.x/256, false)
end

function sion_lightning:frame()
    New(bomb_bullet_killer, self.x, self.y, 100, 100, false)
    if self.timer > 3 then Del(self) end
end

function IsInLaser(x0, y0, a, unit, w)
    local a1 = a - Angle(x0, y0, unit.x, unit.y)
    if a % 180 == 90 then
        if abs(unit.x - x0) < ((unit.a + unit.b + w) / 2) and cos(a1) >= 0 then
            return true
        else
            return false
        end
    else
        local A = tan(a)
        local C = y0 - A * x0
        if abs(A * unit.x - unit.y + C) / hypot(A, 1) <
            ((unit.a + unit.b + w) / 2) and cos(a1) >= 0 then
            return true
        else
            return false
        end
    end
end

function CreateLaser(x, y, a, w, t, c, offset)
    local width = w / 2
    local n = int(offset / 256)
    local length = t % 256
    local endl = int(offset - n * 256)

    local w_x = width * cos(a)
    local w_y = width * sin(a)
    local tex = 'SionLaser'
    local blend = 'mul+add'

    for i = 1, n do
        local vx1 = x + (length + 256 * (i - 1)) * cos(a)
        local vy1 = y + (length + 256 * (i - 1)) * sin(a)
        local vx2 = x + 256 * i * cos(a)
        local vy2 = y + 256 * i * sin(a)
        local vx3 = x + 256 * (i - 1) * cos(a)
        local vy3 = y + 256 * (i - 1) * sin(a)
        RenderTexture(tex, blend, {vx1 - w_y, vy1 + w_x, 0.5, 0, 0, c},
                      {vx2 - w_y, vy2 + w_x, 0.5, 256 - length, 0, c},
                      {vx2 + w_y, vy2 - w_x, 0.5, 256 - length, 16, c},
                      {vx1 + w_y, vy1 - w_x, 0.5, 0, 16, c})
        RenderTexture(tex, blend,
                      {vx3 - w_y, vy3 + w_x, 0.5, 256 - length, 0, c},
                      {vx1 - w_y, vy1 + w_x, 0.5, 256, 0, c},
                      {vx1 + w_y, vy1 - w_x, 0.5, 256, 16, c},
                      {vx3 + w_y, vy3 - w_x, 0.5, 256 - length, 16, c})
    end

    local vx2 = x + (endl + 256 * n) * cos(a)
    local vy2 = y + (endl + 256 * n) * sin(a)
    local vx3 = x + 256 * n * cos(a)
    local vy3 = y + 256 * n * sin(a)
    if length <= endl then
        local vx1 = x + (length + 256 * n) * cos(a)
        local vy1 = y + (length + 256 * n) * sin(a)
        RenderTexture(tex, blend, {vx1 - w_y, vy1 + w_x, 0.5, 0, 0, c},
                      {vx2 - w_y, vy2 + w_x, 0.5, endl - length, 0, c},
                      {vx2 + w_y, vy2 - w_x, 0.5, endl - length, 16, c},
                      {vx1 + w_y, vy1 - w_x, 0.5, 0, 16, c})
        RenderTexture(tex, blend,
                      {vx3 - w_y, vy3 + w_x, 0.5, 256 - length, 0, c},
                      {vx1 - w_y, vy1 + w_x, 0.5, 256, 0, c},
                      {vx1 + w_y, vy1 - w_x, 0.5, 256, 16, c},
                      {vx3 + w_y, vy3 - w_x, 0.5, 256 - length, 16, c})
    else
        RenderTexture(tex, blend,
                      {vx3 - w_y, vy3 + w_x, 0.5, 256 - length, 0, c},
                      {vx2 - w_y, vy2 + w_x, 0.5, endl + 256 - length, 0, c},
                      {vx2 + w_y, vy2 - w_x, 0.5, endl + 256 - length, 16, c},
                      {vx3 + w_y, vy3 - w_x, 0.5, 256 - length, 16, c})
    end
end
