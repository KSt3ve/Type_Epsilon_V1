-- Based on LuaSTG Ex Plus's default Reimu player, with modified bent laser code.
-- Differences between those and this file are by TruDev#4528.

marianne_player = Class(player_class)

function marianne_player:init(slot)
    LoadTexture('marianne_player', 'THlib\\player\\marianne\\marianne.png')
    LoadTexture('marianne_bomb_weapons', 'THlib\\player\\marianne\\marianne_bomb_weapons.png')
    LoadTexture('bomb_teleportCircle', 'THlib\\player\\marianne\\bomb_teleportCircle.png')
    LoadImageGroup('marianne_player', 'marianne_player', 0, 0, 32, 48, 8, 3, 0.5, 0.5)
    LoadImageGroup('marianne_bomb_weapons', 'marianne_bomb_weapons', 0, 0, 56, 56, 4, 5, 0.5, 0.5)
    LoadImage('marianne_bullet_main', 'marianne_player', 0, 144, 16, 16, 16, 16)
    LoadAnimation('marianne_bullet_main_ef', 'marianne_player', 0, 144, 16, 16, 4, 1, 4)
    SetAnimationState('marianne_bullet_main_ef', 'mul+add', Color(0xA0FFFFFF))
    LoadImage('marianne_bullet_short', 'marianne_player', 127, 163, 16, 12, 16, 16)
    SetImageState('marianne_bullet_short', '', Color(0x80FFFFFF))
    LoadAnimation('marianne_bullet_short_ef', 'marianne_player', 127, 163, 16, 12, 4, 1, 4)
    SetAnimationState('marianne_bullet_short_ef', 'mul+add', Color(0xA0FFFFFF))
    LoadImage('marianne_support', 'marianne_player', 64, 144, 16, 16)
    LoadImage('marianne_windrose', 'marianne_player', 0, 192, 64, 64)
    SetImageState('marianne_windrose', '', Color(0xA0FFFFFF))
    LoadAnimation('marianne_windrose_ef', 'marianne_player', 0, 192, 64, 64, 4, 1, 4)
    SetAnimationState('marianne_windrose_ef', 'mul+add', Color(0x80FFFFFF))
    LoadAnimation('bomb_teleportCircle', 'bomb_teleportCircle', 0, 0, 128, 128, 4, 4, 3)
    SetAnimationState('bomb_teleportCircle', '', Color(0xB0FFFFFF))

    player_class.init(self)
    self.name = 'Marianne'
    self.hspeed = 4.5
    self.imgs = {}
    self.A = 0.5
    self.B = 0.5
    for i = 1, 24 do self.imgs[i] = 'marianne_player' .. i end
    self.slist = {
        { nil, nil, nil, nil },
        { { 0, 36, 0, 24 }, nil, nil, nil },
        { { -32, 0, -12, 24 }, { 32, 0, 12, 24 }, nil, nil },
        { { -32, -8, -16, 20 }, { 0, -32, 0, 28 }, { 32, -8, 16, 20 }, nil },
        { { -36, -12, -16, 20 }, { -16, -32, -6, 28 }, { 16, -32, 6, 28 }, { 36, -12, 16, 20 } },
        { { -36, -12, -16, 20 }, { -16, -32, -6, 28 }, { 16, -32, 6, 28 }, { 36, -12, 16, 20 } },
    }
    self.anglelist = {
        { 90, 90, 90, 90 },
        { 90, 90, 90, 90 },
        { 100, 80, 90, 90 },
        { 100, 90, 80, 90 },
        { 110, 100, 80, 70 },
    }
end

-------------------------------------------------------
function marianne_player:shoot()
    PlaySound('plst00', 0.3, self.x / 1024)
    self.nextshoot = 4
    New(marianne_bullet_main, 'marianne_bullet_main', self.x + 8, self.y, 24, 90, 2.4)
    New(marianne_bullet_main, 'marianne_bullet_main', self.x - 8, self.y, 24, 90, 2.4)
    if self.support > 0 then
        if self.slow == 0 then
            for i = 1, 4 do
                if self.sp[i] and self.sp[i][3] > 0.5 then
                    New(marianne_bullet_short, 'marianne_bullet_short', self.supportx + self.sp[i][1] - 3, self.supporty + self.sp[i][2], 24, 93, 0.4)
                    New(marianne_bullet_short, 'marianne_bullet_short', self.supportx + self.sp[i][1] + 3, self.supporty + self.sp[i][2], 24, 87, 0.4)
                end
            end
        else
            if self.timer % 8 < 4 then
                for i = 1, 4 do
                    if self.sp[i] and self.sp[i][3] > 0.5 then
                        New(marianne_homing_laser, self.supportx + self.sp[i][1], self.supporty + self.sp[i][2])
                    end
                end
            end
        end
    end
    local power = int(lstg.var.power / 100)
    if power == 4 and self.timer % 8 < 4 then
        New(marianne_windrose, 'marianne_windrose', self.x, self.y, 6, 90, self.target, 900, 1.8)
    end
end

-------------------------------------------------------
function marianne_player:spell()
    self.collect_line = self.collect_line - 300
    New(tasker, function()
        task.Wait(90)
        self.collect_line = self.collect_line + 300
    end)
    PlaySound('power1', 0.8)
    PlaySound('cat00', 0.8)
    self.nextspell = 300
    self.protect = 360
    misc.ShakeScreen(240, 3)
    New(player_spell_mask, 100, 64, 255, 30, 240, 30)
    New(tasker, function()
        task.Wait(30)
        for i = 1, 30 do
            PlaySound('slash', 0.5)
            New(marianne_teleport, ran:Int(-180, 180), lstg.world.b + 8)
            task.Wait(8)
        end
    end)
end

-------------------------------------------------------
function marianne_player:render()
    for i = 1, 4 do
        if self.sp[i] and self.sp[i][3] > 0.5 then
            Render('marianne_support', self.supportx + self.sp[i][1], self.supporty + self.sp[i][2], self.timer * 3)
        end
    end
    player_class.render(self)
end
-------------------------------------------------------
marianne_weapon = Class(object)

function marianne_weapon:init(x, y)
    self.killflag = true
    self.group = GROUP_PLAYER_BULLET
    self.layer = LAYER_PLAYER_BULLET
    self.img = 'marianne_bomb_weapons' .. ran:Int(1, 19)
    self.a = 50
    self.b = 50
    self.x = x
    self.y = y
    self.rot = 45
    self.vy = 1
    self.ay = 0.1
    self.dmg = 5
end

function marianne_weapon:frame()
    New(bomb_bullet_killer, self.x, self.y, 48, 48, false)
end

-------------------------------------------------------
marianne_teleport = Class(object)

function marianne_teleport:init(x, y)
    self.killflag = true
    self.group = GROUP_GHOST
    self.layer = LAYER_PLAYER_BULLET - 5
    self.img = 'bomb_teleportCircle'
    self.vscale = 0
    self.hscale = 0
    self.x = x
    self.y = y
    self.omiga = 0.5

    task.New(self, function()
        for i = 0, 7 do
            self.hscale = i / 8
            self.vscale = i / 8
            task.Wait(1)
        end
        task.Wait(8)
        New(marianne_weapon, self.x, self.y - 20)
        task.Wait(24)
        for i = 0, 7 do
            self.hscale = 1 - i / 8
            self.vscale = 1 - i / 8
            task.Wait(1)
        end
        Del(self)
    end)
end

function marianne_teleport:frame() task.Do(self) end

-------------------------------------------------------
marianne_bullet_main = Class(player_bullet_straight)

function marianne_bullet_main:init(img, x, y, v, angle, dmg)
    player_bullet_straight.init(self, img, x, y, v, angle, dmg)
    self.a, self.b = 20, 20
end

function marianne_bullet_main:kill()
    New(marianne_bullet_main_ef, self.x, self.y)
end

-------------------------------------------------------
marianne_bullet_main_ef = Class(object)

function marianne_bullet_main_ef:init(x, y)
    self.x = x
    self.y = y
    self.rot = 90
    self.img = 'marianne_bullet_main_ef'
    self.layer = LAYER_PLAYER_BULLET + 50
    self.group = GROUP_GHOST
    self.vy = 2.25
end

function marianne_bullet_main_ef:frame()
    if self.timer == 15 then self.y = 600 Del(self) end
end

-------------------------------------------------------
marianne_bullet_short = Class(player_bullet_straight)

function marianne_bullet_short:kill()
    New(marianne_bullet_short_ef, self.x, self.y)
end

-------------------------------------------------------
marianne_windrose = Class(player_bullet_trail)
function marianne_windrose:init(img, x, y, v, angle, target, trail, dmg)
    self.group = GROUP_PLAYER_BULLET
    self.layer = LAYER_PLAYER_BULLET
    self.img = img
    self.x = x
    self.y = y
    self.rot = ran:Int(0,360)
    self.vrot = 90 + ran:Int(-45, 45)
    self.v = v
    self.target = target
    self.trail = trail
    self.dmg = dmg
end

function marianne_windrose:frame()
    player_class.findtarget(self)
    if IsValid(self.target) and self.target.colli then
        local a = math.mod(Angle(self, self.target) - self.vrot + 720, 360)
        if a > 180 then a = a - 360 end
        local da = self.trail / (Dist(self, self.target) + 1)
        if da >= abs(a) then self.vrot = Angle(self, self.target)
        else self.vrot = self.vrot + sign(a) * da end
    end
    self.vx = self.v * cos(self.vrot)
    self.vy = self.v * sin(self.vrot)
    self.rot = self.rot + 3
end

function marianne_windrose:kill()
    New(marianne_windrose_ef, self.x, self.y, self.rot, self.vx / 6, self.vy / 6)
end

-------------------------------------------------------
marianne_windrose_ef = Class(object)

function marianne_windrose_ef:init(x, y, rot, vx, vy)
    self.x = x
    self.y = y
    self.rot = rot
    self.img = 'marianne_windrose_ef'
    self.layer = LAYER_PLAYER_BULLET + 50
    self.group = GROUP_GHOST
    self.vx = vx
    self.vy = vy
end

function marianne_windrose_ef:frame()
    self.rot = self.rot + 1
    if self.timer > 14 then Del(self) end
end

-------------------------------------------------------
marianne_sp_ef = Class(player_bullet_trail)

function marianne_sp_ef:kill()
    PlaySound('explode', 0.3)
    New(bubble, 'parimg12', self.x, self.y, 30, 4, 6, Color(0xFFFFFFFF), Color(0x00FFFFFF), LAYER_ENEMY_BULLET_EF, '')
    for i = 1, 16 do
        New(marianne_sp_ef2, 16, 16, self.x, self.y, 3, 360 / 16 * i, 0.25, 4, 30)
    end
    misc.KeepParticle(self)
end

function marianne_sp_ef:del()
    misc.KeepParticle(self)
end

-------------------------------------------------------

marianne_bullet_short_ef = Class(object)

function marianne_bullet_short_ef:init(x, y)
    self.x = x
    self.y = y
    self.rot = 90
    self.img = 'marianne_bullet_short_ef'
    self.layer = LAYER_PLAYER_BULLET + 50
    self.group = GROUP_GHOST
    self._blend, self._a, self._r, self._g, self._b = 'mul+add', 240, 255, 255, 255
    self.vy = 2.25
end

function marianne_bullet_short_ef:render()
    -- SetAnimationState('marianne_bullet_short_ef', 'mul+add', Color(self._a, 255, 255, 255))
    SetImgState(self, self._blend, self._a, self._r, self._g, self._b)
    DefaultRenderFunc(self)
end

function marianne_bullet_short_ef:frame()
    self._a = self._a - 15
    self.hscale = self.hscale + 0.1
    self.vscale = self.hscale
    if self.timer == 15 then self.y = 600 Del(self) end
end

-------------------------------------------------------
-- Had to copy the bent laser code from THlib because apparently players load earlier than lasers.
-- Go figure.

LoadTexture('homing_laser', 'THlib\\laser\\laser5.png')

----------------------------------------
---bent lazer

marianne_homing_laser = Class(object)

function marianne_homing_laser:init(x, y)
    self.index = COLOR_RED
    self.x = x
    self.y = y
    -- self.l = max(int(l), 2)
    self.l = 12
    self.w = 8
    self.w0 = 8
    self._w = 8
    self.group = GROUP_PLAYER_BULLET
    self.layer = LAYER_PLAYER_BULLET
    self.data = BentLaserData()
    self.bound = false
    self._bound = true
    self.prex = x
    self.prey = y
    self.listx = {}
    self.listy = {}
    self.node = 0 -- node or 0
    self._l = 3 -- int(l / 4)
    self.img4 = 'laser_node' .. int((self.index + 1) / 2)
    self.pause = 0
    self.a = 0
    self.b = 0
    self.dw = 0
    self.da = 0
    self.alpha = 1
    self.counter = 0
    self._colli = true
    self._inf_graze = true
    self.deactive = 0
    self.sample = 4--by OLC，不使用换class来实现
    self._blend, self._a, self._r, self._g, self._b = 'mul+add', 80, 255, 255, 255

    self.rot = 90
    self.v = 8
    self.vx = self.v * cos(self.rot)
    self.vy = self.v * sin(self.rot)
    self.dmg = 0.5
    self.trail = 900

    setmetatable(self, { __index = GetAttr, __newindex = laser_bent_meta_newindex })
end

function laser_bent_meta_newindex(t, k, v)
    if k == 'bound' then
        rawset(t, '_bound', v)
    elseif k == 'colli' then
        rawset(t, '_colli', v)
    else
        SetAttr(t, k, v)
    end
end

function marianne_homing_laser:frame()
    --by ETC
    task.Do(self)

    SetAttr(self, 'colli', self._colli and self.alpha > 0.999)

    if self.counter > 0 then
        self.counter = self.counter - 1
        self.w = self.w + self.dw
        self.alpha = self.alpha + self.da
    end
    local _l = self._l

    if self.pause > 0 then
        --self.pause=self.pause-1
    else
        if self.timer % 4 == 0 then
            self.listx[(self.timer / 4) % _l] = self.x
            self.listy[(self.timer / 4) % _l] = self.y
        end
        self.data:Update(self, self.l, self.w, self.deactive)
    end

    if self.w ~= self._w then
        marianne_homing_laser.setWidth(self, self.w)
        self._w = self.w
    end

    if self._bound and not self.data:BoundCheck() and
            not BoxCheck(self, lstg.world.boundl, lstg.world.boundr, lstg.world.boundb, lstg.world.boundt) then
        Del(self)
    end
    
    player_class.findtarget(self)
    if IsValid(self.target) and self.target.colli then
        local a = math.mod(Angle(self, self.target) - self.rot + 720, 360)
        if a > 180 then a = a - 360 end
        local da = self.trail / (Dist(self, self.target) + 1)
        if da >= abs(a) then self.rot = Angle(self, self.target)
        else self.rot = self.rot + sign(a) * da end
    end
    self.vx = self.v * cos(self.rot)
    self.vy = self.v * sin(self.rot)
end

function marianne_homing_laser:setWidth(w)
    self.w = w
    self.data:SetAllWidth(self.w)
end

function marianne_homing_laser:render()
    --by OLC
    if laser_bent_renderFunc[self.sample] then
        laser_bent_renderFunc[self.sample](self)
    end
end

function marianne_homing_laser:del()
    New(marianne_homing_laser_death_ef, self.index, self.data, self.sample, self._blend, self._a, self._r, self._g, self._b)
end

function marianne_homing_laser:kill()
    New(marianne_homing_laser_death_ef, self.index, self.data, self.sample, self._blend, self._a, self._r, self._g, self._b)
end

--by OLC，通过换函数的方式改变样式
laser_bent_renderFunc = {
    [0] = function(self)
        self.data:Render('laser_bent2', self._blend, Color(self._a * self.alpha, self._r, self._g, self._b), 0, 32 * (int(0.5 * self.timer) % 4), 256, 32)
        if self.timer < self._l * 4 and self.node then
            local c = Color(self._a, self._r, self._g, self._b)
            SetImageState(self.img4, self._blend, c)
            Render(self.img4, self.prex, self.prey, -3 * self.timer, (8 + self.timer % 3) * 0.125 * self.node / 8)
            Render(self.img4, self.prex, self.prey, -3 * self.timer + 180, (8 + self.timer % 3) * 0.125 * self.node / 8)
        end
    end,
    [4] = function(self)
        self.data:Render('laser3', self._blend, Color(self._a * self.alpha, self._r, self._g, self._b), 0, self.index * 16 - 12, 256, 8)
        if self.timer < self._l * 4 and self.node then
            local c = Color(self._a, self._r, self._g, self._b)
            SetImageState(self.img4, self._blend, c)
            Render(self.img4, self.prex, self.prey, -3 * self.timer, (8 + self.timer % 3) * 0.125 * self.node / 8)
            Render(self.img4, self.prex, self.prey, -3 * self.timer + 180, (8 + self.timer % 3) * 0.125 * self.node / 8)
        end
    end,
}
laser_bent_renderFuncDeath = {
    [0] = function(self)
        self.data:Render('laser_bent2', self._blend, Color(self._a * (1 - self.timer / 30), self._r, self._g, self._b), 0, 32 * (int(0.5 * self.timer) % 4), 256, 32)
    end,
    [4] = function(self)
        self.data:Render('laser3', self._blend, Color(self._a * (1 - self.timer / 30), self._r, self._g, self._b), 0, self.index * 16 - 12, 256, 8)
    end,
}

--by OLC，可自由添加激光类型
function Add_bentlaser_texture(id, tex)
    if id ~= 0 and id ~= 4 then
        local w, h = GetTextureSize(tex)
        laser_bent_renderFunc[id] = function(self)
            self.data:Render(tex, self._blend, Color(self._a * self.alpha, self._r, self._g, self._b), 0, 0, w, h)
            if self.timer < self._l * 4 and self.node then
                local c = Color(self._a, self._r, self._g, self._b)
                SetImageState(self.img4, self._blend, c)
                Render(self.img4, self.prex, self.prey, -3 * self.timer, (8 + self.timer % 3) * 0.125 * self.node / 8)
                Render(self.img4, self.prex, self.prey, -3 * self.timer + 180, (8 + self.timer % 3) * 0.125 * self.node / 8)
            end
        end
        laser_bent_renderFuncDeath[id] = function(self)
            self.data:Render(tex, self._blend, Color(self._a * (1 - self.timer / 30), self._r, self._g, self._b), 0, 0, w, h)
        end
    else
        Print("不能修改默认曲线激光样式")
    end
end
function Add_bentlaser_thunder_texture(id, tex)
    if id ~= 0 and id ~= 4 then
        local w, h = GetTextureSize(tex)
        h = h / 4
        laser_bent_renderFunc[id] = function(self)
            self.data:Render(tex, self._blend, Color(self._a * self.alpha, self._r, self._g, self._b), 0, h * (int(0.5 * self.timer) % 4), w, h)
            if self.timer < self._l * 4 and self.node then
                local c = Color(self._a, self._r, self._g, self._b)
                SetImageState(self.img4, self._blend, c)
                Render(self.img4, self.prex, self.prey, -3 * self.timer, (8 + self.timer % 3) * 0.125 * self.node / 8)
                Render(self.img4, self.prex, self.prey, -3 * self.timer + 180, (8 + self.timer % 3) * 0.125 * self.node / 8)
            end
        end
        laser_bent_renderFuncDeath[id] = function(self)
            self.data:Render(tex, self._blend, Color(self._a * (1 - self.timer / 30), self._r, self._g, self._b), 0, h * (int(0.5 * self.timer) % 4), w, h)
        end
    else
        Print("不能修改默认曲线激光样式")
    end
end

--by ETC
marianne_homing_laser_death_ef = Class(object)
function marianne_homing_laser_death_ef:init(index, data, sample, blend, a, r, g, b)
    self.data = data
    self.sample = sample
    self.index = index

    self.group = GROUP_GHOST
    self.bound = false

    self._blend, self._a, self._r, self._g, self._b = blend, a, r, g, b
end
function marianne_homing_laser_death_ef:frame()
    if self.timer == 30 then
        self.data:Release()
        Del(self)
    end
end
function marianne_homing_laser_death_ef:render()
    if laser_bent_renderFuncDeath[self.sample] then
        laser_bent_renderFuncDeath[self.sample](self)
    end
end
