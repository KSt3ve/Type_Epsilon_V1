Include'THlib\\player\\marianne\\marianne.lua'
AddPlayerToPlayerList('Mirakuru Marianne','marianne_player','Marianne')