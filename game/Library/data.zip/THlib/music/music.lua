music_list = {
    menu = { 'THlib\\music\\luastg 0.08.540 - 1.27.800.ogg', 87.8, 79.26 },
    spellcard = { 'THlib\\music\\spellcard.ogg', 75, 0xc36e80 / 44100 / 4 },
}
